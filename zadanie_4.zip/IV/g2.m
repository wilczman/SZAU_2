function [val] = g2(x1)
    val = -0.7*(1-exp(-2.5*x1));
end