function [val] = g1(u)
    val = (exp(4.25*u) - 1) / (exp(4.25*u)+1);
end